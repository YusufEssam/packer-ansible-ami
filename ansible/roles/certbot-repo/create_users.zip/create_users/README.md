# create user role 
1- Create file  under auth_keys with user name and put in it the public key of the user (do this for each user)
2- To make super users with NOPASSWD add users in 'admins' group
3- Define variables in playbook like this 

 vars:
    users:  
      - name:  user_name
        groups: 
          - secondery_group_of_user
          - admins 
      - name: add_another_user
    key:
      - user_name

